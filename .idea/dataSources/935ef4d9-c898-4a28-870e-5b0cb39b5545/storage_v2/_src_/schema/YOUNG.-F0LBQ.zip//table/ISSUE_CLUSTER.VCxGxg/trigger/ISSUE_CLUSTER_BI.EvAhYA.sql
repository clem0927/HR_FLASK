create trigger ISSUE_CLUSTER_BI
    before insert
    on ISSUE_CLUSTER
    for each row
BEGIN
    :NEW.ISSUE_ID := ISSUE_CLUSTER_SEQ.NEXTVAL;
END;
/

